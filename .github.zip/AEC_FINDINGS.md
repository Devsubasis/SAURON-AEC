# SAURON++ — Action-Contingent Evidence Control: Results

**Status: mechanism implemented, frontier measured, does NOT dominate baselines.
Read §4 before writing any claim.**

---

## 1. The formulation

A security action changes what the defender will be able to observe. A DROP
protects and simultaneously destroys the outcome that would have revealed
whether the DROP was correct. Enforcement and evidence acquisition are coupled
control variables.

Conventional controllers select `a_t` from risk and treat observability as a
consequence. **AEC selects the pair `(a_t, π_t)`** — action and observation
propensity — as one constrained decision:

```
maximise    Protection(a)·risk  +  λ·EvidenceValue(a,π)  −  Collateral(a)  −  MirrorCost(a,π)
subject to  π ∈ Π(a)                    feasibility: the action bounds observability
            π ≥ ε   for censoring a     observability floor
            FPR̂ ≤ B                     priced as a Lagrangian, not a hard ban
```

**The structural content is `Π(a)`.** An action does not merely carry a cost; it
*bounds the set of achievable propensities*. `DROP` observes nothing unless
mirroring is purchased. `ALLOW` observes fully for free. The controller can
therefore reach a target observability either by paying for a mirror on a strong
action, or by choosing a weaker action that observes for free — and which is
cheaper depends on risk, budget, and accumulated evidence debt.

That substitution between **action strength** and **evidence purchase** is what
a scalar authority score cannot represent.

### Evidence debt

```
D(c) = Σ over acted-on, unobserved units of  risk · (1 − π)
```

The state variable coupling the constraints over time. High debt means the
defender is acting on an estimate it can no longer justify.

---

## 2. Security–Evidence frontier (measured)

λ sweep, 3 seeds, 20,000 units per point:

| λ | Protection | Harm | Observability | Debt/exposure | Collateral |
|---|---|---|---|---|---|
| 0.0 | 0.0703 | 0.1007 | 0.9378 | 0.0984 | 0.0005 |
| 0.25 | 0.0693 | 0.1017 | 0.9422 | 0.0948 | 0.0005 |
| 0.5 | 0.0683 | 0.1027 | 0.9448 | 0.0907 | 0.0005 |
| 1.0 | 0.0662 | 0.1048 | 0.9508 | 0.0840 | 0.0005 |
| 2.0 | 0.0628 | 0.1082 | 0.9614 | 0.0725 | 0.0004 |
| 4.0 | 0.0574 | 0.1136 | 0.9770 | 0.0548 | 0.0004 |
| 8.0 | 0.0507 | 0.1203 | **0.9888** | **0.0328** | 0.0004 |

**Monotone in both coordinates.** λ is a working dial: raising the price of
evidence buys observability and debt reduction, and costs protection.

---

## 3. Controller comparison

| Controller | Protection | Observability | Debt/exposure |
|---|---|---|---|
| risk-only | **0.1271** | 0.7927 | 0.3375 |
| fixed-authority (deployed SAURON++) | **0.1271** | 0.7948 | 0.3296 |
| competence-aware | 0.0933 | 0.8760 | 0.2107 |
| **AEC (λ=0)** | 0.0703 | **0.9378** | **0.0984** |
| **AEC (λ=8)** | 0.0507 | **0.9888** | **0.0328** |

Paired tests, 5 seeds: AEC observability exceeds every baseline at **p < 0.0001**.

---

## 4. What this does and does not establish

### AEC does NOT dominate the baselines

At every λ tested, AEC yields **less protection** than risk-only or
fixed-authority. It buys observability by acting more weakly. Anyone reading the
table will see this immediately, so the paper must say it first.

### What AEC does provide

All five operating points are **mutually non-dominated** — each trades
protection for observability at a different rate. The distinction is:

> A fixed controller occupies **one** point on the security–evidence plane and
> cannot move. AEC traces a **continuum**, and reaches operating points
> (observability 0.99, debt 0.03) that no fixed controller in the comparison can
> reach at any setting.

That is a real capability and a defensible claim. It is **not** "AEC is better."

### Evidence quality did not improve

`fp_estimate_mae` was **0.0366 for every controller**, paired p ≈ 0.96. Ten
times more observation did not produce a better false-positive-rate estimate,
because all controllers already observe enough benign traffic to estimate it.

**This is the most important negative result in the file.** The evidence axis
that AEC optimises is *observability and debt*, not estimator accuracy. Claiming
AEC improves estimation would be false and trivially checkable.

---

## 5. A bug found, recorded

The first frontier run was **completely flat** — λ changed nothing across three
orders of magnitude.

Cause: the FP-budget constraint was implemented as a hard exclusion
(`if slack < 0 and collateral > 0.05: continue`). On any stream whose base
false-positive rate exceeds B, the budget is violated at step one and stays
violated, so every collateral-bearing action was banned permanently and λ had
nothing left to influence.

Fix: price the violation as a Lagrangian term rather than forbidding the action.
The controller then degrades smoothly and the trade-off stays controllable.

Recorded because a flat frontier presented as a result would have been a
fabrication, and because the brittleness of hard constraints under sustained
violation is itself worth stating.

---

## 6. Claim status

| Claim | Status | Evidence |
|---|---|---|
| Actions bound achievable observability | **supported by construction** | `Π(a)`, §1 |
| Joint (a,π) selection is implementable in the real loop | **supported** | `backend/aec.py` |
| A measured security–evidence frontier exists | **supported** | §2, monotone |
| λ controls the trade-off | **supported** | §2 |
| AEC reaches operating points fixed controllers cannot | **supported** | §3 |
| AEC dominates baselines on protection | **REFUTED** | §3 — it does not |
| AEC improves FP-rate estimation | **REFUTED** | §4 — p ≈ 0.96 |
| Evidence debt is a useful state variable | **partially** — drives allocation; independent value untested |
| Real-corpus validation | **NOT RUN** | synthetic only |

---

## 7. Honest position for the resubmission

**The defensible thesis:**

> Security actions and evidence acquisition are coupled: the action bounds what
> the defender will be able to observe about it. Treating them as a joint
> constrained decision exposes a security–evidence frontier that fixed
> controllers cannot traverse, and makes the operating point an explicit
> operator choice rather than an emergent property of a threshold.

**What must not be claimed:** that AEC detects better, protects better, or
estimates better. It does none of those in the measurements above.

**What is genuinely unusual:** the framing of observability as a *decision
variable* rather than a consequence, and the resulting frontier as a *measured*
object. I am not aware of this being posed in network security.

**What must be done before submission:**

1. Validate on CTU-13 / UNSW-NB15 with a real context key. Everything above is
   synthetic — necessary, because protection and evidence loss must both be
   scored against ground truth, but not sufficient.
2. Clear prior art on the joint formulation. Terms: *action-dependent
   observability*, *selective labels under intervention*, *evidence-aware
   control*, *coupled decision and measurement*. The closest neighbours are
   selective-labels (Lakkaraju), off-policy evaluation, and dual control — the
   last is the most dangerous, as dual control is explicitly about actions that
   probe while regulating.
3. Decide whether *evidence debt* survives its own test. It is currently a
   mechanism input with no independent validation.

**Dual control is the citation risk.** If a reviewer names it and the paper has
not positioned against it, the contribution collapses. Find it, cite it, and
state the delta — probably that dual control assumes the probe is free of
security consequence, whereas here the probe *is* the security action.
