# Changelog

## v4.0 — Verification, observability & reproducibility

Hardening pass over the v3.0 codebase. No change to the packet path, the
adaptive engine's math, or the mesh protocol — this release makes the existing
system provable, observable, and reproducible.

### Correctness / honesty
- **Real policy distillation in the live server.** The dashboard's
  *pending kernel rules* previously showed placeholder fidelity/coverage. They
  now carry the **measured** fidelity/coverage from the live `PolicyDistiller`
  (the same surrogate the headless harness reports), tagged with the concrete
  offender — no fabricated numbers, matching the README's honesty section.
- **Timestamp footgun fixed.** `AutonomyGovernor.allow_contain/expired` used
  `now or time.time()`, which treated `now == 0.0` as "unset". Now uses an
  explicit `is None` check so `0.0` is a valid timestamp (only affected callers
  passing an explicit epoch of 0; production wall-clock use was unaffected).

### Observability
- **Prometheus `/metrics` endpoint** (text exposition v0.0.4) on the server:
  realized FPR, FP budget, throughput, precision/recall/F1/MCC, p50/p99 decision
  latency, CPU/mem/RSS, per-detector Hedge weights, drift level, kernel/hook
  attach state, and cluster size + distributed-intel count when the mesh is up.
  Every series is measured. Point a Prometheus job at `/metrics` → Grafana.

### Verification
- **39-test suite** (`tests/`, numpy-only, no kernel needed) asserting the
  design's *properties*, not just that code runs:
  - conformal p-values are calibrated (`P(p<=α) ≈ α`); FP budget is held
    end-to-end; Hedge fusion tracks the best expert; trust influence-cap resists
    flooding and anti-laundering asymmetry holds; censored-feedback IPW is an
    unbiased FPR estimator; containment stays proportional.
  - **ECOD contributions are exact Shapley values** — proven by additivity of
    the decomposition; HDC learns class separation and its prototypes quantize
    to `{-1,0,1}` (kernel-distillable); drift martingale fires on shift and stays
    quiet when stationary; distiller-reported fidelity equals an independent
    recomputation; alert dedup + BH-FDR match their definitions; autonomy L2 cap
    and TTL expiry behave; storage round-trips.
  - **mesh**: CRDT LWW merge is commutative + idempotent with correct TTL/latest
    semantics; Krum and coordinate-wise trimmed-mean reject a Byzantine outlier;
    phi-accrual rises on silence; vector clocks detect causality vs concurrency.

### Reproducibility / packaging
- `pyproject.toml` (metadata + dependency extras: `server`, `pcap`, `mesh`,
  `figures`, `dev`, `all`; pytest + ruff config).
- Pinned, grouped `requirements.txt`.
- `Makefile` (`build test lint fmt run headless experiments proto docker …`).
- `Dockerfile` + `.dockerignore` (sim/headless-capable image).
- GitHub Actions `ci.yml`: ruff + pytest + headless smoke + experiment harness
  across Python 3.9/3.11/3.12.
