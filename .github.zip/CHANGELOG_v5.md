# SAURON++ v5.0 — Changelog

## New modules

| File | Lines | Purpose |
|---|---|---|
| `backend/aec.py` | 308 | Action-Contingent Evidence Control — joint selection of the enforcement action and the observation propensity it executes under. Defines the feasible set `Π(a)`, evidence debt `D(c)`, and the constrained objective. |
| `backend/aec_experiments.py` | 103 | Security–Evidence frontier sweep and four-way controller comparison with paired tests. |
| `backend/targeted_feedback.py` | 243 | Drop-in replacement for `CensoredFeedback`. Redistributes the same global ε-mirror budget by estimator variance weighted by exposure. `strategy="uniform"` reproduces v4 behaviour exactly. |

## Bug fixed in `backend/sauron.py`

**`is_benign_label()` — compound-label corpora were completely misclassified.**

The function tested `label.startswith("normal")`. CTU-13 and other Stratosphere
corpora place the class as an *infix*:

```
flow=From-Normal-V42-Stribrek     benign
flow=From-Botnet-V42-UDP-DNS      malicious
```

Every benign flow failed the test and was counted as an attack. The resulting
confusion matrix was degenerate — TP 465,093 · FP 0 · **TN 0** · FN 28,
accuracy 0.99994, **MCC 0.0000**. An accuracy of 0.99994 with MCC 0.0000 is the
signature of a collapsed matrix, not a strong detector.

The fix tests for the class as an infix with malicious tokens taking precedence.
After correction on CTU-13: TP 208,345 · FP 32,888 · TN 169,661 · FN 54,227,
**MCC 0.6263**.

Corpora with plain labels (CICIDS2017, UNSW-NB15, Bot-IoT) were unaffected.

## Not wired in

`aec.py` and `targeted_feedback.py` are standalone. `sauron.py:283` still
constructs the original `CensoredFeedback` with uniform ε-mirror, so all
corpus results in the v5 reports come from the v4 detection path plus the label
fix. They are **not** AEC results, and the reports state this.

To enable targeted allocation:

```python
from targeted_feedback import TargetedCensoredFeedback
self.censor = TargetedCensoredFeedback(strategy="targeted",
                                       rng=np.random.default_rng(seed))
```

## Measured

| | |
|---|---|
| Corpora evaluated | 8 |
| Flows | 4,993,533 |
| MCC range | 0.9950 (CIC-DDoS2019) → 0.6060 (CTU-13) |
| Budget ratio ρ | 1.20 → 12.50 |
| Targeted vs uniform allocation | equal accuracy at 82.4 % of the exploration cost |

## Refuted, and recorded

Two hypotheses were tested and did not survive. Both are documented rather than
dropped, in `AEC_FINDINGS.md` and `TARGETED_EXPLORATION.md`.

1. **Enforcement causes estimation blindness.** The mechanism is real —
   observability 0.451 in enforced regions against 1.000 elsewhere — but the
   consequence does not follow: estimation error is *lower* where the system
   enforces (0.0424 vs 0.0729), because enforcement concentrates on high-volume
   contexts whose sample size dominates the censoring. What concentrates error
   is traffic rarity (3.50×), independent of enforcement.

2. **AEC improves estimation.** FP-estimate MAE is 0.0366 for every controller
   tested, paired p ≈ 0.96.
