# Getting started

This is your SAURON++ codebase with production scaffolding added on top. This
page lists **what's new vs your original version** and gives **copy-paste steps
to run it**. Full detail is in `README.md` and `CHANGELOG.md`.

---

## What was added on top of your version

Your original already had the engine, the novel detector bank, the eBPF datapath,
the **gRPC mesh** (`grpc_service.py`, `sauron.proto`, `sauron_pb2*.py`), and the
dashboard. Those were kept as-is. New in this bundle:

| Area | Files | What it gives you |
|------|-------|-------------------|
| **Live capture** | `backend/sauron.py` (`--source live`, `--list-ifaces`) | Feed your **own wifi/ethernet traffic** in userspace — no eBPF build, works on Windows/macOS/Linux |
| **Prometheus** | `backend/sauron.py` (`GET /metrics`) | Scrape target for Grafana; every series measured |
| **Tests** | `tests/test_sauron.py` | 39 tests proving the math (conformal calibration, FP budget, ECOD exact-Shapley, CRDT convergence, Byzantine robustness …) |
| **Packaging** | `pyproject.toml`, `requirements.txt`, `Makefile` | One-command install / test / run |
| **Docker** | `Dockerfile`, `.dockerignore` | Run the dashboard in a container |
| **CI** | `.github/workflows/ci.yml` | Auto lint + test + smoke run on every push (Python 3.9/3.11/3.12) |
| **Docs** | `CHANGELOG.md`, `README.md` quick-start, this file | — |

Plus small fixes to existing files: real distilled-rule fidelity/coverage on the
dashboard (was placeholder), a `now == 0.0` timestamp footgun, a type-annotation
typo, and a couple of dead assignments.

---

## Which file do I run? Just one.

You run **`backend/sauron.py`**. It starts the web server, serves the dashboard,
and imports the other backend modules automatically. You do **not** run the files
separately. (The kernel C files, tests, and experiment harness are separate,
on-demand tools — not needed for the dashboard.)

---

## Run it — step by step

### Option A — see the dashboard now (any OS, no admin, synthetic traffic)
Everything on the dashboard is live; the traffic is generated, which is the best
way to see attacks + enforcement in action.
```bash
pip install numpy fastapi "uvicorn[standard]" websockets
python backend/sauron.py --source sim
```
Open **http://127.0.0.1:8000/**

### Option B — your own live wifi/ethernet traffic
```bash
pip install scapy
```
Install a capture driver: **Windows → Npcap** (https://npcap.com, tick
"WinPcap API-compatible"); **macOS/Linux → libpcap** (usually already installed).

Find your interface name:
```bash
python backend/sauron.py --list-ifaces
```
Look for your wifi/ethernet entry — typically `"Wi-Fi"` or `Ethernet` (Windows),
`en0` (macOS), `wlan0` / `eth0` (Linux). Then:
```bash
# Windows — run the terminal (or VS Code) as Administrator:
python backend\sauron.py --source live --iface "Wi-Fi"

# macOS / Linux — needs root to open the interface:
sudo python backend/sauron.py --source live --iface wlan0
```
Open **http://127.0.0.1:8000/** and browse a few sites to generate traffic.
> Your own traffic is benign, so expect near-zero drops — that's correct. Use
> Option A (sim) to watch attacks and enforcement.

### Option C — kernel-speed capture + in-kernel enforcement (Linux only)
```bash
./scripts/build.sh                 # needs clang, libbpf, bpftool, a BTF kernel
sudo python backend/sauron.py --source ebpf --iface eth0
```

### Option D — run in Docker (dashboard on the simulator)
```bash
docker build -t sauron:4.0 .
docker run --rm -p 8000:8000 sauron:4.0
```
Open **http://127.0.0.1:8000/**  *(live capture from inside a container needs
`--net=host --privileged`; simplest is Option B on the host.)*

---

## Other things you can run (optional)

```bash
# watch the decision stream in the terminal, no web stack (works with any source)
python backend/sauron.py --headless --source live --iface wlan0

# Prometheus metrics endpoint (while the server is running)
#   http://127.0.0.1:8000/metrics

# run the test suite (only needs numpy + pytest)
pip install pytest
python -m pytest tests/            #  or:  make test

# run the measured experiment harness (writes figures/CSV to results/)
python backend/experiments.py      #  or:  make experiments

# regenerate the gRPC stubs after editing sauron.proto (needs grpcio-tools)
make proto
```

## Handy Make targets
```bash
make help          # list everything
make run           # dashboard on the simulator
make headless      # stream + metrics in the terminal
make test          # 39 unit tests
make docker-run    # dashboard in a container on :8000
```

---

## Troubleshooting
- **`fastapi not installed`** → `pip install fastapi "uvicorn[standard]" websockets` (or add `--headless`).
- **`scapy required for live capture`** → `pip install scapy` and install Npcap (Windows) / libpcap (macOS/Linux).
- **`could not start capture on <iface>`** → wrong interface name (run `--list-ifaces`) or missing admin/root.
- **Dashboard loads but nothing moves in live mode** → generate traffic (open a website); benign traffic rarely triggers drops.
- **Port 8000 busy** → add `--port 8080` and open that port instead.
