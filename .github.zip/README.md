# SAURON++ FIREWALL SYSTEM

**Self-Adaptive Autonomous Runtime Observatory for Unified Resilient Networking++** — an adaptive, autonomous eBPF network-intelligence platform. Packets are observed and enforced in the kernel (XDP / TC / LSM); a userspace Adaptive Decision Engine scores every flow, holds a **false-positive budget**, resists poisoning, and de-biases its own censored feedback; a live SOC dashboard streams the whole loop over WebSockets.

This repository is a **runnable reference implementation** of the architecture. It is designed for research, experimental validation, and extension. It runs three ways from one codebase:

| Mode | Traffic source | Needs |
|------|----------------|-------|
| `sim`  | labeled synthetic traffic with realistic attack families | numpy only |
| `live` | **your own live wifi/ethernet traffic**, captured in userspace | scapy + libpcap/Npcap + admin |
| `pcap` | streaming replay of a real capture (e.g. CICIDS2017, tens of GB) | scapy |
| `ebpf` | the real kernel data path via libbpf + CO-RE (kernel-speed, in-kernel enforcement) | Linux + BTF kernel + root |

The engine, detectors, pipeline, and dashboard are identical across all four; only the packet source changes.

---

## Quick start — run it and open the dashboard

You run **one** file: `backend/sauron.py`. It starts the web server and serves the
dashboard itself, importing the other backend modules automatically. You do
**not** run the files individually.

**1. See the dashboard immediately (any OS, no admin) — synthetic traffic:**
```bash
pip install numpy fastapi "uvicorn[standard]" websockets
python3 backend/sauron.py --source sim
# open http://127.0.0.1:8000/
```

**2. Feed your own live wifi/ethernet traffic (Linux/macOS/Windows):**
```bash
pip install scapy                       # plus a driver: libpcap (Linux/macOS) or Npcap (Windows)
python3 backend/sauron.py --list-ifaces # find your interface name (e.g. "Wi-Fi", en0, wlan0)

# Linux/macOS (needs root to open the interface):
sudo python3 backend/sauron.py --source live --iface wlan0
# Windows (run the terminal as Administrator):
python  backend\sauron.py --source live --iface "Wi-Fi"
# open http://127.0.0.1:8000/  and browse the web to generate traffic
```

**3. Kernel-speed capture with in-kernel enforcement (Linux only):**
```bash
./scripts/build.sh                      # compiles the eBPF object + loader (clang/libbpf/BTF)
sudo python3 backend/sauron.py --source ebpf --iface eth0
```

Tip: append `--headless` to any of the above to watch the decision stream in the
terminal without the web stack (e.g. `python3 backend/sauron.py --headless --source live --iface wlan0`).

---

## Project layout

```
SAURON++/
├── kernel/
│   ├── sauron.h            shared kernel↔user structs & metric slots
│   ├── sauron.bpf.c        CO-RE BPF: XDP ingress + TC egress + LSM connect
│   └── sauron_loader.c     libbpf loader/bridge (JSON stdout, BLOCK stdin)
├── backend/
│   └── sauron.py           adaptive engine + detectors + sources + telemetry
│                           + FastAPI WebSocket server (one file)
├── frontend/
│   ├── index.html          React SOC dashboard (self-contained, CDN React)
│   └── ebpf_logo.png       watermark asset
├── scripts/
│   ├── build.sh            compile BPF object + loader, set up Python env
│   └── run.sh              launch backend in sim / pcap / ebpf mode
└── README.md
```

The loader (`sauron_loader.c`) is the one file beyond the minimal layout: loading a
CO-RE object without BCC is done in idiomatic libbpf C, so the privileged kernel
work lives there while Python owns analytics and the WebSocket server. They talk
over a pipe.

---

## Requirements

**Userspace (all modes):** Python 3.9+, `numpy`. Server mode adds `fastapi`,
`uvicorn`, `websockets`. PCAP mode adds `scapy`. `scripts/build.sh` installs
these into a local `.venv`.

**Kernel data path (`ebpf` mode):** a Linux kernel with BTF
(`CONFIG_DEBUG_INFO_BTF=y`), and the build toolchain `clang`, `llvm`,
`libbpf-dev`, `libelf-dev`, `zlib1g-dev`, `bpftool`. The LSM hook additionally
needs `CONFIG_BPF_LSM=y` and `bpf` present in `/sys/kernel/security/lsm`
(otherwise it is skipped and the loader reports `lsm:0`). Attaching XDP/TC and
loading BPF programs requires root (or `CAP_BPF`+`CAP_NET_ADMIN`).

Install the toolchain (Debian/Ubuntu):

```bash
sudo apt install clang llvm libbpf-dev libelf-dev zlib1g-dev \
                 linux-tools-common linux-tools-$(uname -r) bpftool make gcc
```

---

## Quickstart

```bash
# 1. Build (sets up Python env; compiles eBPF if the toolchain is present)
./scripts/build.sh

# 2a. Simulation — runs anywhere, no kernel needed
./scripts/run.sh sim
#    open http://localhost:8000/

# 2b. Real kernel data path — XDP/TC/LSM on a live interface
sudo ./scripts/run.sh ebpf eth0

# 2c. PCAP replay
./scripts/run.sh pcap /data/CICIDS2017.pcap
```

No-web sanity check (numpy only, prints the decision stream + metrics):

```bash
python3 backend/sauron.py --headless --source sim --events 4000
```

Expected: the realized false-positive rate converges to the budget
(`realized_fpr ≈ 0.016` vs `eps_H = 0.02`), MCC ≈ 0.75, adaptive thresholds
climb from 0.60 toward ~0.88, and open-set discovery flags unknown families.

---

## CICIDS2017 (~24 GB) replay

The reader is streaming (`scapy.PcapReader`), so memory stays flat regardless of
file size. CIC ground-truth labels are not in the PCAP, so replayed flows are
**unlabeled** and the engine runs in autonomous mode (conservative self-training
under bounded influence).

```bash
# single pcap
./scripts/run.sh pcap /data/CICIDS2017/Friday-WorkingHours.pcap

# whole dataset: concatenate first (mergecap ships with Wireshark)
mergecap -w /data/CICIDS2017_all.pcap /data/CICIDS2017/*.pcap
./scripts/run.sh pcap /data/CICIDS2017_all.pcap
```

For a hardware-in-the-loop test that exercises the **real XDP path** with the
dataset, replay onto an interface with `tcpreplay` and run `ebpf` mode against
that interface:

```bash
sudo tcpreplay -i eth0 --mbps=1000 /data/CICIDS2017_all.pcap &
sudo ./scripts/run.sh ebpf eth0
```

---

## The dashboard

Title bar shows realized FPR, F1·MCC, and throughput at a glance. Panels:

- **Kernel Data-Path** — live packets flowing XDP → TC → SK_LOOKUP → LSM,
  colored by action; drops/quarantines are absorbed at the ingress stage.
- **System Telemetry** — packet rate, bitrate, active flows, CPU, memory,
  p99 decision latency, dropped, quarantined, drop rate, and XDP/TC/LSM hook
  status.
- **Detector Bank** — live Hedge fusion weights and per-detector anomaly
  signals, plus the **FP-budget gauge** (realized FPR vs the budget marker).
- **Adaptive Score Evolution** — the aggregate threat score Aₜ against the
  self-tuning τH / τL bands (the signature view of the adaptive loop).
- **Alert Center** — every threat with a **reason**, top contributing features,
  severity, and the mitigation applied; plus an Allowed ticker and a full flow
  log. **Historical replay** freezes the buffer and lets you scrub back through it.
- **Rule Engine vs SAURON++** — the same traffic judged by a frozen static rule
  set vs the adaptive engine, with distilled rules pending analyst approval.
- **Threat Surface & Unknown Discovery** — a src×dst intensity heatmap and the
  open-set candidate families.

Footer controls (pause, replay, speed, **FP budget εH**, deployment profile)
are wired live to the backend over the WebSocket and REST.

If no backend is reachable (e.g. you open `index.html` directly), the dashboard
falls back to an in-browser simulator so it is never blank; it switches to live
telemetry automatically once a server is connected.

---

## How the adaptive loop works (map to the design)

`backend/sauron.py` implements design Section 11 faithfully:

- **11.1 Conformal calibration** — per-detector split-conformal p-values turn
  raw scores into calibrated anomaly signals.
- **11.2 Hedge fusion** — multiplicative-weights + fixed-share fusion with
  tracking-regret guarantees; weights follow drift.
- **11.3 Trust** — discounted Beta-Bernoulli entity reputation with an influence
  cap and anti-laundering asymmetry; UCB suspicion.
- **11.4 Budgeted thresholds** — Robbins-Monro quantile tracking holds
  `P(Aₜ > τH | benign) = εH` per context, with a hysteresis band.
- **11.5 Censored feedback** — ε-mirror exploration + inverse-propensity
  weighting so false-positive drops don't hide their own error.
- **12 Detector bank** — a GBDT stand-in, an AE-family online Gaussian, and
  streaming Half-Space Trees (diverse inductive biases), plus an open-set guard.

The kernel side (`kernel/sauron.bpf.c`) is design Section 7: XDP fast-path
enforcement (blocklist + verdict cache), TC egress accounting, an LSM connect
monitor, per-CPU metrics, and a ring buffer that punts sampled flow records to
userspace. On `QUARANTINE`, the backend programs the offending source into the
kernel blocklist map through the loader, closing the enforcement loop.

---

## Metrics & honesty

Detection metrics (precision/recall/F1/MCC) require labels and are therefore
meaningful in `sim` mode; in `pcap`/`ebpf` mode without labels the engine runs
autonomously and those counters reflect only what labels are present.

CPU, memory, and decision-latency percentiles are measured from `/proc` and
around the scoring path — they are real in every mode. XDP/TC/LSM packet
counters come from the kernel per-CPU maps and are populated **only** when the
eBPF data path is attached (`ebpf` mode); in `sim`/`pcap` mode the dashboard
shows them as unattached rather than fabricating values. The p99 decision
latency reported is the **userspace analytics** latency; the kernel XDP path is
the line-rate component and is benchmarked separately on the testbed.

The simulator's numbers are illustrative of the loop's behavior, not
paper-final results; those come from the CICIDS2017 evaluation on the testbed.

---

## Troubleshooting

- **`clang`/`bpftool` not found** → eBPF build is skipped; `sim` and `pcap`
  modes still work. Install the toolchain above for `ebpf` mode.
- **`ebpf` mode exits immediately** → needs root and a BTF kernel; check
  `ls /sys/kernel/btf/vmlinux` and run with `sudo`.
- **LSM shows `—`** → kernel lacks `CONFIG_BPF_LSM` or `bpf` isn't in the active
  LSM list; XDP/TC still work.
- **PCAP mode errors** → `pip install scapy` (or re-run `build.sh`).
- **Dashboard blank when opened as a file** → serve it via the backend
  (`run.sh`) so the WebSocket and asset routes resolve.

---

## v2.0 — Novel intelligence layer, measured experiments, kernel completeness

This revision fills the gaps against the design doc and raises novelty by using
methods **under-used in the NIDS literature** (which leans on XGBoost + autoencoder
+ Isolation Forest).

### New detector bank (`backend/intelligence.py`)
A streaming, integer/sketch-friendly bank feeding the conformal→Hedge→trust→budget
controller. Rarely combined in NIDS:

| Detector | What it is | Why here |
|---|---|---|
| **HDC** | Hyperdimensional Computing classifier (bipolar prototypes) | rare in NIDS; ±1 prototypes are natively distillable to the kernel |
| **ECOD** | Empirical-CDF (copula) outlier detection | **additive score ⇒ per-feature contributions are *exact* Shapley values** (real attribution, not a TreeSHAP stand-in) |
| **SR** | Spectral Residual saliency (frequency domain) | catches low-and-slow / periodic beacons |
| **RRCF** | Robust-random-cut-style streaming isolation (CoDisp) | different inductive bias ⇒ strengthens the fusion regret guarantee |

Also added and wired into the engine: conformal-martingale **drift detection**,
**Model Manager** (canary/shadow/rollback), **real policy distillation** (fitted
depth-1/2 rules with measured fidelity/coverage), **Alert Manager**
(dedup + correlation + BH-FDR + lifecycle), **SQLite** event store + append-only
**audit log**, and **autonomy guardrails** (L2 global rate-cap + TTL auto-expiry).

### Kernel completeness (`kernel/`)
Added to the CO-RE datapath: in-kernel **Count-Min sketch** (heavy hitters) and
**HyperLogLog** (destination fan-out) [C4/§7.4]; a fourth **`cgroup/connect4`**
hook [§7.1/§7.6]; **punt token-bucket** admission with a starvation counter
[§7.5]; and a **quantized verdict cache** (`{action, score_band, rate, TTL}`) so a
decided flow is enforced at line rate with no punt [§7.3/C1]. The loader merges the
sketches and emits `heavy_hitter` + `fanout_cardinality`. Compiles on a Linux box
with clang/bpftool/libbpf-dev via `scripts/build.sh` (not compilable in the sandbox).

### Experiments (`backend/experiments.py`) — measured, honest
Run `python3 backend/experiments.py` (writes `results/results.csv` + figures):

| Exp | Hyp | Result | Verdict |
|---|---|---|---|
| E3 | H1 | fusion tracks the regime-best expert: PR-AUC **1.00** vs best-fixed-single **0.57** | PASS |
| E4 | H2 | under drift, adaptive threshold **1.2×** budget vs static **12.5×** | PASS |
| E5 | H3 | repeat-offender time-to-mitigation **7.3 vs 24 pkts**; alerts **4 vs 65** | PASS |
| E6 | H4 | ε-mirror recovers a false-positive state (median **T_rec≈309** events); no-explore never recovers | PASS |
| E7 | H5 | best distilled kernel rule fidelity **0.951**; aggregate union modest on sim (95%/60% target needs real CICIDS2017) | mechanism validated |
| LOAFO | — | held-out attack family mean recall **0.67**, open-set flag **0.07** | PASS |

Real novel-bank per-detector PR-AUC on the sim is reported for transparency
(HDC strong; ECOD moderate; SR/RRCF weak on this synthetic data — the sim is
easily separable, so the fusion advantage is shown in the drift/heterogeneity
regime H1 actually targets).

### Honesty notes
The adaptive engine (§11), the novel bank, drift/model-manager/distiller/alerts/
storage/autonomy, and the experiment harness are real and validated headless. The
eBPF additions compile on a real kernel (not in this sandbox). The simulator is
illustrative; paper-final numbers require the real datapath + CICIDS2017 replay.

---

## v3.0 — Distributed mesh (gRPC, node-to-node)

SAURON++ nodes now form a **self-organising distributed mesh** for shared threat
intelligence, adaptive-policy sync, telemetry sharing, federated model sync,
heartbeat/failure detection, node discovery and cluster health — suitable for
cloud-native, edge, 5G/6G/B6G fabrics. **gRPC is used only between nodes.**
WebSocket stays backend↔dashboard; ring buffer + BPF maps stay kernel↔user.
The packet path is untouched (mesh runs on the asyncio loop; all remote failures
are contained by per-peer circuit breakers).

New files (only two): `backend/grpc_service.py` and `backend/sauron.proto`
(the `*_pb2*.py` stubs auto-generate on first run if absent).

**What's inside** — SWIM membership + **phi-accrual** failure detector, epidemic
anti-entropy **gossip**, distributed threat intel as an **LWW-element-set CRDT**
with TTL, **vector-clock** causal policy sync, and **Byzantine-robust federated
model** aggregation (Krum + coordinate-wise trimmed mean; applying it back into
the ADE is opt-in and off by default). Optional **mTLS**.

### Install
```
pip install grpcio grpcio-tools --break-system-packages
```

### Run a 3-node cluster (one shell each; same host demo)
```
# node A (seed)
SAURON_MESH_ENABLE=1 SAURON_NODE_ID=A SAURON_MESH_REGION=edge \
  SAURON_MESH_BIND=0.0.0.0:50151 SAURON_MESH_ADVERTISE=127.0.0.1:50151 \
  ./scripts/run.sh sim          # dashboard on :8000

# node B
SAURON_MESH_ENABLE=1 SAURON_NODE_ID=B SAURON_MESH_REGION=5g \
  SAURON_MESH_BIND=0.0.0.0:50152 SAURON_MESH_ADVERTISE=127.0.0.1:50152 \
  SAURON_MESH_SEEDS=127.0.0.1:50151 python3 backend/sauron.py --source sim --port 8001

# node C
SAURON_MESH_ENABLE=1 SAURON_NODE_ID=C SAURON_MESH_REGION=6g \
  SAURON_MESH_BIND=0.0.0.0:50153 SAURON_MESH_ADVERTISE=127.0.0.1:50153 \
  SAURON_MESH_SEEDS=127.0.0.1:50151 python3 backend/sauron.py --source sim --port 8002
```
A threat detected on any node propagates to all peers within ~1–2 gossip rounds
and is programmed into every node's kernel blocklist. Cluster state is exposed to
the dashboard over the existing transport and at `GET /api/cluster`, `/api/intel`,
`/api/cluster/telemetry`, `/api/federated-model`, and `POST /api/cluster/policy`.

### Enable mTLS (production)
```
SAURON_MESH_TLS_CERT=node.crt SAURON_MESH_TLS_KEY=node.key SAURON_MESH_TLS_CA=ca.crt ...
```

### Env reference
`SAURON_MESH_ENABLE, SAURON_NODE_ID, SAURON_MESH_BIND, SAURON_MESH_ADVERTISE,
SAURON_MESH_SEEDS, SAURON_MESH_REGION, SAURON_MESH_APPLY_MODEL,
SAURON_MESH_TLS_CERT/_KEY/_CA`

---

## v4.0 — Verification, observability & reproducibility

A hardening pass that makes the system **provable, observable, and
reproducible**. The packet path, the adaptive-engine math, and the mesh
protocol are unchanged; this release adds proof and plumbing around them.
Full detail in `CHANGELOG.md`.

### Test suite (`tests/`, numpy-only)
`make test` (or `pytest tests/`) runs 39 tests that assert the design's
*properties*, not just that code runs — conformal calibration (`P(p≤α)≈α`),
end-to-end FP-budget adherence, Hedge tracking of the best expert, the trust
influence-cap and anti-laundering asymmetry, unbiased IPW under censored
feedback, and enforcement proportionality; **ECOD's exact-Shapley additivity**,
HDC separation + `{-1,0,1}` prototype quantization, the drift martingale (fires
on shift, quiet when stationary), and distiller fidelity equal to an independent
recomputation; and, for the mesh, **CRDT LWW commutativity + idempotence** and
**Byzantine rejection by Krum / trimmed-mean**, phi-accrual, and vector-clock
causality. Runs anywhere numpy is installed — no kernel required.

### Prometheus metrics
The server now exposes `GET /metrics` in Prometheus text-exposition format
(alongside the JSON `GET /api/metrics`). Every series is measured — realized
FPR, FP budget, throughput, P/R/F1/MCC, p50/p99 decision latency, CPU/mem/RSS,
per-detector Hedge weights, drift level, kernel/hook attach state, and (with the
mesh up) cluster size + distributed-intel count. Point a Prometheus job at it
and graph in Grafana:

```yaml
scrape_configs:
  - job_name: sauron
    static_configs: [{ targets: ["localhost:8000"] }]
```

### Real distilled rules on the dashboard
The *pending kernel rules* panel now shows the **measured** fidelity/coverage
from the live `PolicyDistiller` (the same surrogate the experiment harness
reports), not placeholder numbers.

### Packaging / CI
`pyproject.toml` (dependency extras `server` / `pcap` / `mesh` / `figures` /
`dev` / `all`), a pinned `requirements.txt`, a `Makefile`
(`make help` for targets), a `Dockerfile` for a sim/headless-capable image, and
a GitHub Actions workflow running ruff + pytest + a headless smoke run + the
experiment harness on Python 3.9 / 3.11 / 3.12.

```bash
make test          # 39 unit tests (numpy only)
make headless      # stream + metrics, no web stack
make experiments   # measured experiment harness -> results/
make docker-run    # dashboard in a container on :8000
```
