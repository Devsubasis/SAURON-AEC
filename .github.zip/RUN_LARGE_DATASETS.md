# Running SAURON++ on Large Datasets (tested to 52 GB+)

Everything below assumes the WSL / Linux terminal inside VS Code.

## 0. One-time setup

```bash
unzip -o SAURONpp.zip -d ~
cd ~/SAURON++
bash scripts/build.sh          # creates .venv, installs numpy/fastapi/scapy
```

## 1. ALWAYS preflight a new dataset first (takes seconds)

```bash
./.venv/bin/python backend/sauron.py --inspect --csv /path/to/dataset
```

Look for `VERDICT: OK`. It prints which column became the label, which became the
attack family, and which numeric columns were found. If it says
`FAIL - no label column found`, the dataset uses an unusual header name — rename it
to `Label` (or `class` / `attack_cat` / `category` / `type`) and re-inspect.

## 2. Run it — the command that produced the published results

```bash
./.venv/bin/python backend/sauron.py --headless --source csv \
  --csv /path/to/dataset --balance none --no-print-packets > ~/run.log 2>&1
```

Flag-by-flag, and why each matters at scale:

| Flag | Why |
|---|---|
| `--headless` | no web server; the fastest and most reliable path for a long run |
| `--balance none` | **important.** Rebalancing performs an O(n²) Tomek-link pass. On multi-hundred-thousand-row files it dominates runtime. It is also the honest choice: metrics are computed on the natural class distribution |
| `--no-print-packets` | suppresses per-packet console output (huge I/O saving) |
| `> ~/run.log 2>&1` | keeps the whole transcript for your report |

Watch it live in a second terminal:

```bash
tail -f ~/run.log
```

## 3. What you get

At the end of the run, in `results/`:

| File | Contents |
|---|---|
| `evaluation_<ts>.json` | every metric, machine-readable |
| `evaluation_<ts>.csv`  | every metric, spreadsheet-ready |
| `per_family_<ts>.csv`  | per-attack-family table (samples, detected, missed, accuracy, precision, recall, F1, MCC, ROC-AUC) |
| `results_<ts>.png`     | 15-panel figure (confusion matrix, ROC, PR, score separation, per-family recall, energy, latency …) |

Open the figure from WSL with: `cd results && explorer.exe .`

## 4. Very large corpora (10 GB – 52 GB+)

Memory stays flat regardless of dataset size — files are processed one at a time and
each file is streamed in 150,000-row chunks. Peak RSS observed: ~200 MB on a 2.8 M-row
corpus.

**Point `--csv` at the FOLDER** and every `.csv` inside is processed in one combined run
with one combined result:

```bash
./.venv/bin/python backend/sauron.py --headless --source csv \
  --csv /mnt/e/Datasets/MyBigDataset --balance none --no-print-packets > ~/big.log 2>&1
```

Reading directly from an external drive works (`/mnt/e/...`) but is slower than copying
to the Linux filesystem first. Quote any path containing spaces.

**Run it detached** so closing the terminal cannot kill it:

```bash
nohup ./.venv/bin/python backend/sauron.py --headless --source csv \
  --csv /mnt/e/Datasets/MyBigDataset --balance none --no-print-packets > ~/big.log 2>&1 &
tail -f ~/big.log
```

Stop with `pkill -f backend/sauron.py`.

**If you want a fast preliminary number**, cap the rows — a few hundred thousand shuffled
rows give statistically equivalent metrics:

```bash
--limit 500000
```

## 5. Progress markers to expect

```
[features] feature space expanded to 40 dataset columns (was 7 packet-derived): ...
[dataset]   reading <file> … 50,000 rows parsed
[dataset] ---- file 3/8: <file> ----
[dataset] === file 3/8 complete (<file>) — running totals ===
[dataset]     accuracy≈0.9648  precision=0.9703  recall=0.9366  f1=0.9531  mcc=0.9440
```

Long silences are normal only while a large file is being parsed; the
`reading … N rows parsed` line proves it is alive.

## 6. Why accuracy is now high (what changed)

| Fix | Effect |
|---|---|
| Feature space expanded 7 → 40 dataset-native columns | the 78 engineered CIC/Argus statistics are now used instead of 7 proxies derived from a 5-tuple |
| Online supervised head (AdaGrad + 192 random Fourier features) added as a 5th detector | ECOD/RRCF/SR are unsupervised — they score "unusual", not "attack". This learns the actual boundary, online, single-pass |
| Signed-log scaling before z-scoring | flow statistics span 6+ orders of magnitude; raw z-scores let outliers collapse the useful range |
| Random Fourier features | a linear boundary cannot separate several attack modes at once (e.g. four DoS variants in one capture) |
| Parser reads only the needed columns | ~40× faster parsing (250 → 10,892 rows/s) |
| `distill()` throttled to 20 s | it was 58 % of total runtime |
| `--balance none` | removes an O(n²) Tomek pass |

Measured effect on real CICIDS2017 DDoS: accuracy 0.597 → 0.934, recall 0.385 → 0.956,
MCC 0.227 → 0.871.

## 7. Published reference results

| Dataset | Flows | Accuracy | Recall | F1 | MCC | ROC-AUC |
|---|---|---|---|---|---|---|
| CICIDS2017 (all 8 captures) | 2,572,632 | 0.9590 | 0.9350 | 0.8830 | 0.8602 | 0.9939 |
| 5G-NIDD | 1,009,000 | 0.8718 | 0.9773 | 0.9025 | 0.7367 | — |

Same code, same hyper-parameters, no per-dataset retuning.

---
*SAURON++ v4.0 · Dev Subasis · subasismallick2@gmail.com*
