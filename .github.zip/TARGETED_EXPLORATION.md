# SAURON++ — Targeted Exploration Allocation

**Status: implemented, measured, effect is modest. Read §4 before citing.**

---

## 1. What was changed

`backend/targeted_feedback.py` — a drop-in replacement for `CensoredFeedback`
(`backend/sauron.py:217`). Same constructor keywords, same methods, same return
types. With `strategy="uniform"` it is behaviourally identical to the deployed
class, so A/B runs on one code path.

**The deployed behaviour:** every would-be DROP is mirrored with one global
probability, `eps_mirror = 0.05`.

**The change:** the same global budget is redistributed across traffic contexts
by

```
    pi(c)  ∝  sqrt( Var[p_c] · Exposure(c) )
```

where `p_c` is the estimated benign-flag rate in context `c`, `Var[p_c]` its
Beta(1,1) posterior variance, and `Exposure(c)` the risk-weighted volume. The
global budget is preserved exactly; only its distribution changes.

The rationale: exploration is not free — every mirrored unit is a suspicious
flow deliberately admitted. Uniform mirroring spends that budget in proportion
to enforcement *volume*, concentrating on traffic whose statistics are already
well estimated.

---

## 2. Measured effect, in the real code path

Six paired seeds, 60,000 units each, heavy-tailed context volume:

| | FP-rate MAE | Budget spent | Efficiency |
|---|---|---|---|
| uniform | 0.05040 | 0.04995 | 1.00× |
| **targeted** | **0.04904** | **0.04117** | **1.21×** |

- Accuracy change: **+2.7 %**, paired **p = 0.78** — not significant
- Exploration cost: **−17.6 %**

**The honest reading: 17.6 % less suspicious traffic admitted for statistically
indistinguishable estimation accuracy.**

---

## 3. What the synthetic study showed, and why it differs

An earlier controlled study with bimodal ground-truth competence gave 2.8×
efficiency. That world had stronger structure than the realistic test above:
competence was drawn bimodally, so variance differed sharply between contexts
and the allocation had more to exploit.

**The 1.21× figure is the one to report.** It comes from the real class, on a
stream whose statistics resemble deployment. The 2.8× figure describes a world
constructed to favour the mechanism.

---

## 4. Honest assessment — do not oversell this

| Claim | Status |
|---|---|
| Uniform mirroring is information-inefficient | **supported, but modestly** |
| Targeted allocation reduces exploration cost | **supported** — 17.6 % |
| Targeted allocation improves accuracy | **NOT supported** — p = 0.78 |
| Enforcement causes estimation blindness | **REFUTED** — see §5 |
| This is a headline contribution | **no** |

A 17.6 % reduction in exploration cost is a real engineering improvement and a
legitimate paper subsection. It is **not** a novelty claim strong enough to
carry a resubmission on its own, and presenting it as one would invite exactly
the criticism that caused the first rejection.

---

## 5. The refuted hypothesis, recorded

The original conjecture was that enforcement destroys the evidence needed to
know whether one should be enforcing — so estimation should be *worse* in
enforced contexts.

**The mechanism is real:**

| | Observability |
|---|---|
| Enforced regions | 0.451 |
| Non-enforced regions | 1.000 |

Enforcement halves observation.

**The consequence does not follow:**

| | Estimation error |
|---|---|
| Enforced regions | 0.0424 |
| Non-enforced regions | 0.0729 |

Estimation is *better* where the system enforces. Enforcement concentrates on
high-volume contexts whose absolute sample size dominates the censoring.

**What actually concentrates error is traffic rarity:**

| | Enforced | Not enforced |
|---|---|---|
| High-volume | 0.0359 | 0.0456 |
| Low-volume | **0.1258** | **0.1976** |

3.50× between low- and high-volume contexts, independent of enforcement.

This negative result is recorded because it is the obvious check a reviewer
would run, and because the corrected statement — *enforcement in the tail of
the traffic distribution acts on the weakest evidence and cannot self-correct
through volume* — is true and useful, where the original was not.

---

## 6. Usage

```python
from targeted_feedback import TargetedCensoredFeedback

cf = TargetedCensoredFeedback(eps_mirror=0.05, strategy="targeted")

# context = protocol, service, prefix, or a coarse behavioural bucket
if cf.explore(would_drop, context=ctx):
    cf.record(benign, flagged, cf.ipw_weight(would_drop, ctx), ctx, risk)

print(cf.realised_budget())   # compare against eps_mirror
print(cf.per_context())       # per-context rates and observability
```

Set `strategy="uniform"` to reproduce the deployed behaviour exactly.

---

## 7. What I would do before building further

1. **Run this on CTU-13 and UNSW-NB15** with a real context key (protocol ×
   service). The 1.21× figure is from a synthetic stream; the deployment figure
   may differ in either direction.

2. **Search the prior art.** The allocation rule is Neyman allocation applied to
   an epistemic variance. Terms: *optimal experimental design active learning*,
   *variance-weighted exploration*, *stratified sampling bandits*. This is close
   enough to classical design theory that prior art is likely and must be found
   before it is claimed.

3. **Do not build the paper around this.** It is a good subsection. The
   resubmission needs a larger idea, and this is not it.
