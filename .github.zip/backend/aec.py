"""SAURON++ — Action-Contingent Evidence Control (AEC).

THE PROBLEM
-----------
A security action changes what the defender will be able to observe. A DROP
protects, and simultaneously destroys the outcome that would have told the
defender whether the DROP was correct. Enforcement and evidence acquisition are
therefore not independent: they are coupled control variables.

Conventional controllers select an action a_t from risk alone and treat
observability as a consequence. AEC selects the PAIR (a_t, pi_t) -- the action
and the observation propensity it will be executed under -- as one constrained
decision.

WHY THIS IS NOT A WEIGHTED SCORE
--------------------------------
A weighted authority score maps signals to a single scalar and thresholds it.
AEC solves a constrained problem over a two-dimensional decision space in which
the two coordinates trade against each other:

    maximise    Protection(a)  -  lambda * EvidenceLoss(a, pi)
    subject to  FPR_hat  <=  B                       (security constraint)
                pi(a)    >=  eps  for censoring a    (observability constraint)
                pi       in  Pi(a)                   (feasibility: the action
                                                      bounds what is observable)

The last constraint is the structural content. An action does not merely have a
cost; it bounds the set of achievable propensities. DROP admits pi in {0} union
[eps, eps_max] -- you observe nothing unless you deliberately mirror. ALLOW
admits pi = 1 for free. RATE_LIMIT admits partial observation at no extra
exposure. The controller can therefore reach a target observability either by
paying for a mirror on a strong action, or by choosing a weaker action that
observes for free -- and which is cheaper depends on risk, budget and how much
evidence the context is missing.

That substitution between *action strength* and *evidence purchase* is what a
scalar score cannot represent.

EVIDENCE DEBT
-------------
We track, per context, the accumulated risk-weighted mass on which the
defender acted without observing the outcome:

    D(c)  =  sum over enforced, unobserved units of  risk * (1 - pi)

Debt is the state variable that couples the two constraints over time: a
context with high debt has an estimate the defender can no longer justify, and
AEC responds by either buying observation or by weakening the action.

WHAT IS NOT CLAIMED
-------------------
IPW, conformal calibration, no-regret fusion and Neyman allocation are
established and are used, not claimed. The claim under test is the joint
formulation and whether it produces a measurably better security-evidence
trade-off than selecting the action alone.
"""
from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, Hashable, List, Optional, Sequence, Tuple

import numpy as np

# Action ladder. `protection` is the fraction of malicious impact prevented;
# `collateral` the fraction of benign utility lost; `free_obs` the propensity
# obtained WITHOUT paying for a mirror; `censoring` marks actions that suppress
# the outcome unless deliberately mirrored.
ACTIONS: Tuple[str, ...] = ("ALLOW", "LOG", "MIRROR", "RATE_LIMIT",
                            "QUARANTINE", "DROP")

SPEC: Dict[str, Dict[str, float]] = {
    "ALLOW":      dict(protection=0.00, collateral=0.000, free_obs=1.00, censoring=0),
    "LOG":        dict(protection=0.05, collateral=0.000, free_obs=1.00, censoring=0),
    "MIRROR":     dict(protection=0.25, collateral=0.010, free_obs=1.00, censoring=0),
    "RATE_LIMIT": dict(protection=0.50, collateral=0.060, free_obs=0.55, censoring=1),
    "QUARANTINE": dict(protection=0.80, collateral=0.180, free_obs=0.10, censoring=1),
    "DROP":       dict(protection=0.95, collateral=0.260, free_obs=0.00, censoring=1),
}


@dataclass
class CtxState:
    """Per-context evidence state."""
    flagged: float = 0.0        # IPW-weighted benign units flagged
    seen: float = 0.0           # IPW-weighted benign units observed
    n_acted: int = 0
    n_observed: int = 0
    exposure: float = 0.0       # risk-weighted volume
    debt: float = 0.0           # EVIDENCE DEBT: acted-on, unobserved mass

    def fp_mean(self) -> float:
        return float((self.flagged + 1.0) / (self.seen + 2.0))

    def fp_var(self) -> float:
        a = self.flagged + 1.0
        b = max(self.seen - self.flagged, 0.0) + 1.0
        n = a + b
        return float(a * b / (n * n * (n + 1.0)))

    def observability(self) -> float:
        return float(self.n_observed / max(self.n_acted, 1))


@dataclass
class AECDecision:
    action: str
    propensity: float
    protection: float
    evidence_value: float
    objective: float
    debt_before: float
    feasible_set: int
    reason: str

    def to_dict(self) -> Dict:
        return {"action": self.action, "pi": round(self.propensity, 4),
                "protection": round(self.protection, 4),
                "evidence_value": round(self.evidence_value, 5),
                "objective": round(self.objective, 5),
                "debt": round(self.debt_before, 3),
                "feasible": self.feasible_set, "reason": self.reason}


class AECController:
    """Jointly selects (action, observation propensity).

    Controllers compared in the evaluation:

      risk_only        a = f(risk); pi is whatever the action leaves.
                       No evidence reasoning. The conventional baseline.
      fixed_authority  a = f(risk) capped at a fixed ceiling; uniform eps-mirror
                       on censoring actions. This is deployed SAURON++.
      competence       a bounded by a competence estimate; uniform eps-mirror.
      aec              joint constrained selection over (a, pi).
    """

    MODES = ("risk_only", "fixed_authority", "competence", "aec")

    def __init__(self, mode: str = "aec", lam: float = 1.0,
                 eps: float = 0.05, eps_max: float = 0.35,
                 fp_budget: float = 0.02, authority_cap: int = 5,
                 debt_weight: float = 1.0, seed: int = 7):
        if mode not in self.MODES:
            raise ValueError(f"mode must be one of {self.MODES}")
        self.mode = mode
        self.lam = lam                 # price of evidence loss
        self.eps = eps                 # observability floor on censoring actions
        self.eps_max = eps_max         # most observation we will ever buy
        self.B = fp_budget
        self.cap = authority_cap
        self.debt_weight = debt_weight
        self.rng = np.random.default_rng(seed)
        self.S: Dict[Hashable, CtxState] = defaultdict(CtxState)
        self._fp_num = 0.0
        self._fp_den = 0.0
        self._mirror_spend = 0.0
        self._n = 0

    # ------------------------------------------------------------ estimates --
    def realized_fpr(self) -> float:
        return self._fp_num / self._fp_den if self._fp_den > 0 else 0.0

    def budget_slack(self) -> float:
        """How much FP budget remains, normalised. Negative means overspent."""
        return float((self.B - self.realized_fpr()) / max(self.B, 1e-9))

    # ------------------------------------------------- feasible propensities --
    def _feasible(self, action: str) -> List[float]:
        """The set of propensities this action admits.

        This is the structural coupling: the action bounds what can be
        observed. A censoring action observes nothing for free, so any
        observation must be purchased by mirroring, up to eps_max. A
        non-censoring action observes fully at no cost.
        """
        sp = SPEC[action]
        if not sp["censoring"]:
            return [sp["free_obs"]]
        base = sp["free_obs"]
        out = [base]
        p = max(self.eps, base)
        while p <= self.eps_max + 1e-9:
            out.append(round(p, 4))
            p += 0.10
        return sorted(set(out))

    # ------------------------------------------------------------ objective --
    def _evidence_value(self, ctx: CtxState, pi: float, risk: float) -> float:
        """Expected reduction in estimator uncertainty from observing at pi,
        weighted by exposure and by how much debt this context carries.

        Var[p_c] falls roughly as 1/n, so an extra expected observation is worth
        proportionally more where n is small -- which is exactly where debt has
        accumulated. This is what makes evidence value context-dependent rather
        than a constant per mirrored unit.
        """
        v = ctx.fp_var()
        debt_pressure = 1.0 + self.debt_weight * math.log1p(ctx.debt)
        return float(pi * math.sqrt(max(v, 1e-12)) * debt_pressure
                     * (0.25 + 0.75 * risk))

    def _mirror_cost(self, action: str, pi: float, risk: float) -> float:
        """Cost of buying observation: a mirrored unit is a suspicious flow
        deliberately admitted, so cost scales with residual risk and with how
        much protection is being given up."""
        sp = SPEC[action]
        extra = max(pi - sp["free_obs"], 0.0)
        return float(extra * risk * sp["protection"])

    # --------------------------------------------------------------- decide --
    def decide(self, ctx_key: Hashable, risk: float,
               competence: float = 1.0) -> AECDecision:
        self._n += 1
        c = self.S[ctx_key]

        # ---- baselines -----------------------------------------------------
        if self.mode in ("risk_only", "fixed_authority", "competence"):
            want = int(round(float(np.clip(risk, 0, 1)) * (len(ACTIONS) - 1)))
            if self.mode == "fixed_authority":
                want = min(want, self.cap)
            elif self.mode == "competence":
                ceil_ = int(round(float(np.clip(competence, 0, 1)) * (len(ACTIONS) - 1)))
                want = min(want, ceil_)
            a = ACTIONS[want]
            sp = SPEC[a]
            # risk_only leaves observability to chance; the other two apply the
            # deployed uniform eps-mirror on censoring actions
            pi = sp["free_obs"] if self.mode == "risk_only" else (
                max(sp["free_obs"], self.eps) if sp["censoring"] else sp["free_obs"])
            return AECDecision(a, pi, sp["protection"],
                               self._evidence_value(c, pi, risk), 0.0,
                               c.debt, 1, f"{self.mode}: risk-indexed action")

        # ---- AEC: joint constrained selection ------------------------------
        slack = self.budget_slack()
        best: Optional[Tuple[float, str, float]] = None
        n_feasible = 0
        # Budget pressure: 0 while inside budget, growing once overspent. Used
        # as a Lagrangian price on collateral rather than as a hard ban.
        pressure = max(0.0, -slack)
        for a in ACTIONS:
            sp = SPEC[a]
            for pi in self._feasible(a):
                # observability constraint on censoring actions
                if sp["censoring"] and pi < self.eps and sp["protection"] > 0.4:
                    continue
                n_feasible += 1
                protection = sp["protection"] * risk
                ev = self._evidence_value(c, pi, risk)
                coll = sp["collateral"] * (1.0 - risk) * (1.0 + 4.0 * pressure)
                mcost = self._mirror_cost(a, pi, risk)
                obj = protection + self.lam * ev - coll - mcost
                if best is None or obj > best[0]:
                    best = (obj, a, pi)

        if best is None:                       # every option infeasible
            return AECDecision("LOG", 1.0, SPEC["LOG"]["protection"],
                               self._evidence_value(c, 1.0, risk), 0.0,
                               c.debt, 0, "AEC: no feasible (a,pi); degraded to LOG")
        obj, a, pi = best
        return AECDecision(a, pi, SPEC[a]["protection"] * risk,
                           self._evidence_value(c, pi, risk), obj, c.debt,
                           n_feasible, "AEC: joint (a,pi) argmax under constraints")

    # --------------------------------------------------------------- update --
    def observe(self, ctx_key: Hashable, d: AECDecision, risk: float,
                benign: bool, flagged: bool) -> bool:
        """Execute the decision. Returns whether the outcome was observed.

        Evidence debt accrues on the unobserved fraction -- that is the state
        which makes the coupling dynamic rather than a per-step trade-off.
        """
        c = self.S[ctx_key]
        c.n_acted += 1
        c.exposure += risk
        sp = SPEC[d.action]
        if sp["censoring"]:
            self._mirror_spend += max(d.propensity - sp["free_obs"], 0.0)
        observed = bool(self.rng.random() < d.propensity)
        if observed:
            c.n_observed += 1
            w = 1.0 / max(d.propensity, 1e-6)      # IPW
            if benign:
                c.seen += w
                self._fp_den += w
                if flagged:
                    c.flagged += w
                    self._fp_num += w
        else:
            c.debt += risk * (1.0 - d.propensity)
        return observed

    # ------------------------------------------------------------ reporting --
    def snapshot(self) -> Dict:
        tot_debt = sum(s.debt for s in self.S.values())
        tot_exp = sum(s.exposure for s in self.S.values())
        obs = [s.observability() for s in self.S.values() if s.n_acted > 0]
        return {"mode": self.mode, "decisions": self._n,
                "realized_fpr": round(self.realized_fpr(), 5),
                "fp_budget": self.B,
                "budget_ratio": round(self.realized_fpr() / max(self.B, 1e-9), 3),
                "evidence_debt": round(tot_debt, 2),
                "debt_per_exposure": round(tot_debt / max(tot_exp, 1e-9), 5),
                "mean_observability": round(float(np.mean(obs)), 4) if obs else 0.0,
                "mirror_spend": round(self._mirror_spend, 2),
                "contexts": len(self.S)}
