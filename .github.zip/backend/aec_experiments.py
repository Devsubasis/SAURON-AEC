"""SAURON++ — AEC evaluation. Security-Evidence frontier + controller comparison."""
from __future__ import annotations
import math
from typing import Dict, List, Tuple
import numpy as np
from aec import AECController, ACTIONS, SPEC


class Stream:
    """Traffic with heavy-tailed context volume and per-context malice rate.

    Ground truth is controlled so protection and evidence loss can both be
    scored -- impossible on a real corpus, which is why the frontier experiment
    is synthetic by necessity.
    """
    def __init__(self, seed=3, n_ctx=24):
        r = np.random.default_rng(seed)
        self.ctx = [f"c{i}" for i in range(n_ctx)]
        self.vol = r.dirichlet(np.ones(n_ctx) * 0.35)      # heavy-tailed
        self.mal = {c: float(r.beta(2, 6)) for c in self.ctx}
        self.fp = {c: float(r.beta(2, 18)) for c in self.ctx}   # true FP rate
        self.comp = {c: float(r.beta(8, 2) if r.random() < .7 else r.beta(2, 5))
                     for c in self.ctx}
        self.r = r

    def draw(self):
        c = self.ctx[int(self.r.choice(len(self.ctx), p=self.vol))]
        mal = self.r.random() < self.mal[c]
        risk = float(np.clip((self.r.beta(6, 2) if mal else self.r.beta(2, 6)), 0, 1))
        flagged = (self.r.random() < self.fp[c]) if not mal else True
        return c, risk, (not mal), flagged


def run(mode: str, lam: float = 1.0, n: int = 40000, seed: int = 3,
        eps: float = .05, fp_budget: float = .02) -> Dict:
    st = Stream(seed)
    ac = AECController(mode=mode, lam=lam, eps=eps, fp_budget=fp_budget, seed=seed + 1)
    prot = 0.0; harm = 0.0; coll = 0.0
    for _ in range(n):
        c, risk, benign, flagged = st.draw()
        d = ac.decide(c, risk, competence=st.comp[c])
        sp = SPEC[d.action]
        if not benign:
            prot += sp["protection"] * risk        # malicious impact prevented
            harm += (1 - sp["protection"]) * risk  # impact that got through
        else:
            coll += sp["collateral"]               # benign utility lost
        ac.observe(c, d, risk, benign, flagged)
    s = ac.snapshot()
    # estimator quality against ground truth -- the evidence axis
    err = [abs(ac.S[c].fp_mean() - st.fp[c]) for c in st.ctx if ac.S[c].seen > 0]
    return {**s, "protection": float(prot / n), "harm": float(harm / n),
            "collateral": float(coll / n),
            "fp_estimate_mae": float(np.mean(err)) if err else 1.0,
            "contexts_estimated": len(err), "contexts_total": len(st.ctx)}


def frontier(seeds: int = 4, n: int = 30000) -> Dict:
    """E-FRONTIER: sweep lambda, the price of evidence, and trace the
    protection/observability trade-off. Points are measured, not illustrative."""
    lams = (0.0, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0)
    pts = []
    for lam in lams:
        rows = [run("aec", lam=lam, n=n, seed=3 + s) for s in range(seeds)]
        pts.append({
            "lambda": lam,
            "protection": float(np.mean([r["protection"] for r in rows])),
            "harm": float(np.mean([r["harm"] for r in rows])),
            "observability": float(np.mean([r["mean_observability"] for r in rows])),
            "debt_per_exposure": float(np.mean([r["debt_per_exposure"] for r in rows])),
            "fp_mae": float(np.mean([r["fp_estimate_mae"] for r in rows])),
            "collateral": float(np.mean([r["collateral"] for r in rows])),
            "budget_ratio": float(np.mean([r["budget_ratio"] for r in rows]))})
    # a real frontier: observability must rise and protection fall as lambda grows
    obs_up = pts[-1]["observability"] > pts[0]["observability"]
    prot_dn = pts[-1]["protection"] <= pts[0]["protection"] + 1e-6
    return {"points": pts, "observability_increases": obs_up,
            "protection_decreases": prot_dn,
            "is_frontier": bool(obs_up and prot_dn), "seeds": seeds}


def controllers(seeds: int = 5, n: int = 30000) -> Dict:
    """E-CTRL: risk-only vs fixed-authority vs competence vs AEC, matched seeds."""
    out = {}
    for m in ("risk_only", "fixed_authority", "competence", "aec"):
        rows = [run(m, lam=1.0, n=n, seed=3 + s) for s in range(seeds)]
        out[m] = {k: float(np.mean([r[k] for r in rows]))
                  for k in ("protection", "harm", "collateral", "mean_observability",
                            "debt_per_exposure", "fp_estimate_mae", "budget_ratio")}
        out[m]["_raw"] = {k: [r[k] for r in rows]
                          for k in ("protection", "fp_estimate_mae", "mean_observability")}
    def paired(a, b, k):
        d = np.array(out[a]["_raw"][k]) - np.array(out[b]["_raw"][k])
        if len(d) < 3 or d.std(ddof=1) == 0: return 0., 1.
        t = float(d.mean() / (d.std(ddof=1) / math.sqrt(len(d))))
        return t, float(2 * (1 - .5 * (1 + math.erf(abs(t) / math.sqrt(2)))))
    tests = {}
    for b in ("risk_only", "fixed_authority", "competence"):
        t1, p1 = paired("aec", b, "mean_observability")
        t2, p2 = paired(b, "aec", "fp_estimate_mae")
        tests[b] = {"observability_t": round(t1, 3), "observability_p": round(p1, 5),
                    "fp_mae_t": round(t2, 3), "fp_mae_p": round(p2, 5)}
    return {"controllers": out, "paired_tests": tests, "seeds": seeds}
