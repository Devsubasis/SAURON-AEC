#!/usr/bin/env bash
# ============================================================================
# SAURON++ build script
# ----------------------------------------------------------------------------
# Compiles the CO-RE BPF object and the libbpf loader, and prepares the Python
# environment. The eBPF pieces require a Linux host with the toolchain below;
# the backend + dashboard run without them (sim / pcap modes).
#
# Prerequisites for the eBPF data path (install once):
#   Debian/Ubuntu:  sudo apt install clang llvm libbpf-dev libelf-dev zlib1g-dev \
#                                    linux-tools-common linux-tools-$(uname -r) \
#                                    bpftool make gcc
#   Fedora/RHEL:    sudo dnf install clang llvm libbpf-devel elfutils-libelf-devel \
#                                    zlib-devel bpftool make gcc
#   Kernel must expose BTF (CONFIG_DEBUG_INFO_BTF=y). The LSM hook additionally
#   needs CONFIG_BPF_LSM=y and "bpf" in /sys/kernel/security/lsm.
# ============================================================================
set -u
cd "$(dirname "$0")/.."
ROOT="$(pwd)"
KDIR="$ROOT/kernel"
GREEN='\033[92m'; YELLOW='\033[93m'; RED='\033[91m'; NC='\033[0m'
say(){ printf "${GREEN}[build]${NC} %s\n" "$1"; }
warn(){ printf "${YELLOW}[build]${NC} %s\n" "$1"; }
err(){ printf "${RED}[build]${NC} %s\n" "$1"; }

SAMPLE_N="${SAMPLE_N:-1}"           # override to sample 1/N packets to userspace
BUILD_EBPF=1

# ---- 1. Python environment ------------------------------------------------
say "Setting up Python environment"
PY="${PYTHON:-python3}"
if [ ! -d "$ROOT/.venv" ]; then
  "$PY" -m venv "$ROOT/.venv" 2>/dev/null && say "created .venv" || warn "venv unavailable; using system Python"
fi
if [ -d "$ROOT/.venv" ]; then PIP="$ROOT/.venv/bin/pip"; PYBIN="$ROOT/.venv/bin/python"; else PIP="$PY -m pip"; PYBIN="$PY"; fi
$PIP install --upgrade pip >/dev/null 2>&1
say "Installing Python dependencies (numpy fastapi uvicorn websockets)"
$PIP install numpy fastapi "uvicorn[standard]" websockets >/dev/null 2>&1 \
  && say "core deps installed" || warn "could not install core deps (check network); sim/headless still needs numpy"
$PIP install scapy >/dev/null 2>&1 && say "scapy installed (PCAP replay enabled)" \
  || warn "scapy not installed; PCAP replay (--source pcap) will be unavailable"

# ---- 2. eBPF toolchain check ---------------------------------------------
for t in clang bpftool; do
  command -v "$t" >/dev/null 2>&1 || { warn "'$t' not found -> skipping eBPF build (sim/pcap modes still work)"; BUILD_EBPF=0; }
done
[ -e /sys/kernel/btf/vmlinux ] || { warn "/sys/kernel/btf/vmlinux missing (no BTF kernel) -> skipping eBPF build"; BUILD_EBPF=0; }

if [ "$BUILD_EBPF" -eq 0 ]; then
  warn "eBPF object not built. Backend runs with: ./scripts/run.sh sim"
  say "Build finished (userspace only)."
  exit 0
fi

# ---- 3. vmlinux.h (CO-RE) -------------------------------------------------
say "Generating kernel/vmlinux.h from running-kernel BTF"
bpftool btf dump file /sys/kernel/btf/vmlinux format c > "$KDIR/vmlinux.h" \
  || { err "vmlinux.h generation failed"; exit 1; }

# ---- 4. Compile BPF object (CO-RE) ---------------------------------------
ARCH="$(uname -m | sed 's/x86_64/x86/; s/aarch64/arm64/; s/armv7l/arm/; s/ppc64le/powerpc/; s/mips.*/mips/; s/s390x/s390/')"
say "Compiling BPF object (arch=$ARCH, SAMPLE_N=$SAMPLE_N)"
clang -g -O2 -Wall -target bpf -D__TARGET_ARCH_${ARCH} -DSAMPLE_N=${SAMPLE_N} \
  -I "$KDIR" -c "$KDIR/sauron.bpf.c" -o "$KDIR/sauron.bpf.o" \
  || { err "BPF compile failed"; exit 1; }
command -v llvm-strip >/dev/null 2>&1 && llvm-strip -g "$KDIR/sauron.bpf.o"
say "built kernel/sauron.bpf.o"

# ---- 5. Compile libbpf loader --------------------------------------------
say "Compiling libbpf loader"
CC="${CC:-clang}"
$CC -g -O2 -Wall -I "$KDIR" "$KDIR/sauron_loader.c" -o "$KDIR/sauron_loader" \
  -lbpf -lelf -lz -lm \
  || { err "loader compile failed (is libbpf-dev installed?)"; exit 1; }
say "built kernel/sauron_loader"

printf "${GREEN}[build] SAURON++ build complete.${NC}\n"
echo   "  Live traffic : sudo ./scripts/run.sh ebpf <iface>"
echo   "  PCAP replay  : ./scripts/run.sh pcap /path/to/CICIDS2017.pcap"
echo   "  Simulation   : ./scripts/run.sh sim"
