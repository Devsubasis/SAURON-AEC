#!/usr/bin/env bash
# ============================================================================
# SAURON++ run script
# ----------------------------------------------------------------------------
#   ./scripts/run.sh sim                         # synthetic labeled traffic
#   ./scripts/run.sh pcap /data/CICIDS2017.pcap  # replay a real capture
#   sudo ./scripts/run.sh ebpf eth0              # real kernel XDP/TC/LSM path
#
# Then open http://localhost:8000/  (the dashboard is served by the backend).
# ============================================================================
set -u
cd "$(dirname "$0")/.."
ROOT="$(pwd)"
MODE="${1:-sim}"
HOST="${HOST:-127.0.0.1}"
PORT="${PORT:-8000}"

if [ -x "$ROOT/.venv/bin/python" ]; then PY="$ROOT/.venv/bin/python"; else PY="${PYTHON:-python3}"; fi
URL="http://${HOST}:${PORT}/"

open_browser(){ (sleep 2; command -v xdg-open >/dev/null && xdg-open "$URL" >/dev/null 2>&1 \
  || (command -v open >/dev/null && open "$URL" >/dev/null 2>&1)) & }

echo "SAURON++ FIREWALL SYSTEM"
echo "  mode : $MODE"
echo "  URL  : $URL"

case "$MODE" in
  sim)
    open_browser
    exec "$PY" backend/sauron.py --source sim --host "$HOST" --port "$PORT"
    ;;
  pcap)
    PCAP="${2:-}"
    [ -z "$PCAP" ] && { echo "usage: $0 pcap /path/to/capture.pcap"; exit 1; }
    [ -f "$PCAP" ] || { echo "pcap not found: $PCAP"; exit 1; }
    open_browser
    exec "$PY" backend/sauron.py --source pcap --pcap "$PCAP" --host "$HOST" --port "$PORT"
    ;;
  ebpf)
    IFACE="${2:-eth0}"
    if [ "$(id -u)" -ne 0 ]; then echo "ebpf mode needs root: sudo $0 ebpf $IFACE"; exit 1; fi
    [ -f "$ROOT/kernel/sauron.bpf.o" ] && [ -x "$ROOT/kernel/sauron_loader" ] \
      || { echo "kernel objects missing. Run ./scripts/build.sh first."; exit 1; }
    open_browser
    exec "$PY" backend/sauron.py --source ebpf --iface "$IFACE" --host "$HOST" --port "$PORT"
    ;;
  headless)
    exec "$PY" backend/sauron.py --headless --source "${2:-sim}" --events "${3:-4000}"
    ;;
  *)
    echo "usage: $0 [sim|pcap <file>|ebpf <iface>|headless]"; exit 1 ;;
esac
