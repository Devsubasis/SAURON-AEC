"""SAURON++ test suite — one file covering the whole system.

Sections:
  1. Adaptive Decision Engine (backend/sauron.py) — conformal calibration,
     FP-budget adherence, Hedge tracking, trust caps, censored-feedback IPW,
     enforcement proportionality.
  2. Intelligence layer (backend/intelligence.py) — ECOD exact-Shapley
     additivity, HDC, drift martingale, distiller honesty, alerting, autonomy,
     storage.
  3. Distributed mesh (backend/grpc_service.py) — CRDT LWW convergence,
     Byzantine-robust aggregation, phi-accrual, vector clocks.

Numpy-only; no kernel or gRPC transport required. Run with `pytest tests/`.
"""
from __future__ import annotations

import itertools
import os
import random
import sys

import numpy as np
import pytest

# backend/ holds flat modules (sauron, intelligence, grpc_service); put it on path
_HERE = os.path.dirname(os.path.abspath(__file__))
_BACKEND = os.path.join(os.path.dirname(_HERE), "backend")
if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)

import sauron as S            # noqa: E402
import intelligence as I      # noqa: E402
import grpc_service as G      # noqa: E402


@pytest.fixture(autouse=True)
def _determinism():
    """Seed global RNGs before every test (modules also seed their own)."""
    random.seed(1234)
    np.random.seed(1234)
    yield


# ###########################################################################
# SECTION 1 — ADAPTIVE DECISION ENGINE  (backend/sauron.py)
# ###########################################################################


# --------------------------------------------------------------------------- #
# 11.1  Conformal calibration                                                 #
# --------------------------------------------------------------------------- #
def test_conformal_pvalues_are_calibrated():
    """Under exchangeability, P(p <= alpha) ~ alpha. We feed i.i.d. benign
    scores into the calibrator, then check the empirical CDF of the p-values of
    *fresh* benign draws matches the diagonal (the split-conformal guarantee)."""
    rng = np.random.default_rng(0)
    cal = S.ConformalCalibrator(window=4000, warmup=50)
    for s in rng.uniform(0, 1, size=4000):
        cal.observe_benign(float(s))

    fresh = rng.uniform(0, 1, size=6000)
    pvals = np.array([cal.p_value(float(s)) for s in fresh])
    for alpha in (0.05, 0.1, 0.2, 0.5):
        emp = float(np.mean(pvals <= alpha))
        assert abs(emp - alpha) < 0.03, f"alpha={alpha}: empirical {emp:.3f}"


def test_conformal_anomaly_is_monotone():
    """anomaly = 1 - p is monotone non-decreasing in the raw score."""
    cal = S.ConformalCalibrator(window=1000, warmup=10)
    for s in np.linspace(0, 1, 500):
        cal.observe_benign(float(s))
    lo = cal.anomaly(0.1)
    hi = cal.anomaly(0.95)
    assert hi >= lo
    assert 0.0 <= lo <= 1.0 and 0.0 <= hi <= 1.0


# --------------------------------------------------------------------------- #
# 11.2  Hedge / fixed-share fusion                                            #
# --------------------------------------------------------------------------- #
def test_hedge_weights_are_a_simplex():
    f = S.HedgeFusion(k=4)
    rng = np.random.default_rng(1)
    for _ in range(500):
        sig = rng.uniform(0, 1, size=4)
        f.update(sig, float(rng.integers(0, 2)))
        w = f.weights
        assert np.all(w >= 0)
        assert abs(w.sum() - 1.0) < 1e-9


def test_hedge_tracks_the_best_expert():
    """Expert 0 always equals the label; the others are noise. Hedge must put
    the most mass on expert 0 (multiplicative-weights guarantee)."""
    f = S.HedgeFusion(k=3, alpha=0.01)
    rng = np.random.default_rng(2)
    for _ in range(2000):
        y = float(rng.integers(0, 2))
        sig = np.array([y, rng.uniform(0, 1), rng.uniform(0, 1)])
        f.update(sig, y)
    w = f.weights
    assert np.argmax(w) == 0
    assert w[0] > 0.5


# --------------------------------------------------------------------------- #
# 11.3  Trust: influence cap + anti-laundering asymmetry                      #
# --------------------------------------------------------------------------- #
def test_trust_influence_cap_bounds_a_single_update():
    """One event may move (a,b) by at most `cap`, so a flood cannot dominate."""
    tm = S.TrustModel(cap=1.0)
    e = "10.0.0.9"
    before = tm._s[e].a + tm._s[e].b
    tm.update(e, malicious=1.0, weight=1000.0)   # try to slam it
    after = tm._s[e].a + tm._s[e].b
    # discounting shrinks the prior mass; the *added* evidence is <= cap.
    assert (after - (before * tm.lam_mal)) <= tm.cap + 1e-9


def test_trust_anti_laundering_is_asymmetric():
    """Malicious evidence must forget slower than benign, so a bad source can't
    rapidly wash its reputation with a burst of benign traffic."""
    tm = S.TrustModel()
    assert tm.lam_mal > tm.lam_ben
    e = "10.0.0.5"
    for _ in range(50):
        tm.update(e, malicious=1.0)     # establish bad reputation
    bad = tm.trust(e)
    for _ in range(50):
        tm.update(e, malicious=0.0)     # attempt to launder
    laundered = tm.trust(e)
    # it recovers *somewhat* but the malicious mass persists longer than benign
    assert laundered < 0.98
    assert laundered > bad


def test_trust_suspicion_upper_bounds_rare_bad_entity():
    """UCB suspicion should not under-penalise a rarely-seen-but-bad entity."""
    tm = S.TrustModel()
    e = "203.0.113.7"
    tm.update(e, malicious=1.0)         # one bad observation
    assert tm.suspicion(e) >= tm._s[e].b / (tm._s[e].a + tm._s[e].b)
    assert tm.suspicion(e) <= 1.0


# --------------------------------------------------------------------------- #
# 11.4  Budgeted adaptive threshold                                           #
# --------------------------------------------------------------------------- #
def test_adaptive_threshold_holds_the_budget():
    """Feeding a stationary benign score stream, the exceed-rate P(A>tau_H)
    converges to eps_H (Robbins-Monro quantile tracking)."""
    eps = 0.05
    at = S.AdaptiveThreshold(eps_h=eps)
    rng = np.random.default_rng(3)
    ctx = "TCP"
    scores = rng.uniform(0, 1, size=20000)
    for s in scores:
        at.update_benign(ctx, float(s))
    tau = at.tau_high(ctx)
    # The step is floored (gamma_min) so the tracker never fully stops adapting —
    # it can follow drift, at the cost of exact convergence. It therefore holds
    # the exceed-rate *near* the budget (and slightly conservative, which is the
    # safe direction for a firewall), not exactly on it.
    exceed = float(np.mean(scores[-5000:] > tau))
    assert abs(exceed - eps) < 0.03, f"exceed={exceed:.3f} tau={tau:.3f}"
    assert 0.90 < tau < 0.99                     # ~0.95 quantile of U(0,1)
    assert at.tau_low(ctx) < at.tau_high(ctx)    # hysteresis band


# --------------------------------------------------------------------------- #
# 11.5  Censored feedback / IPW                                               #
# --------------------------------------------------------------------------- #
def test_ipw_weight_is_inverse_propensity():
    cf = S.CensoredFeedback(eps_mirror=0.05, pi_min=0.05)
    assert cf.propensity(False) == 1.0            # allowed → fully observed
    assert cf.propensity(True) == pytest.approx(0.05)
    assert cf.ipw_weight(True) == pytest.approx(1.0 / 0.05)


def test_ipw_realized_fpr_is_unbiased():
    """With a known benign FP probability q, the IPW estimator of the realized
    FPR recovers q even though would-be-drops are mostly censored."""
    cf = S.CensoredFeedback(eps_mirror=0.1, pi_min=0.1, rng=np.random.default_rng(4))
    q = 0.2                                       # true benign flag-rate
    rng = np.random.default_rng(5)
    for _ in range(40000):
        flagged = bool(rng.random() < q)
        would_drop = flagged                      # a flag would cause a drop
        if cf.explore(would_drop):                # censoring: only observed sometimes
            cf.record(benign=True, flagged=flagged, ipw=cf.ipw_weight(would_drop))
    assert abs(cf.realized_fpr() - q) < 0.03, cf.realized_fpr()


# --------------------------------------------------------------------------- #
# Proportionality of enforcement (design §13)                                 #
# --------------------------------------------------------------------------- #
def _decision(score, suspicion, tau_high=0.6, tau_low=0.5, unknown=False):
    return S.Decision(
        action="PASS", aggregate=score, raw_aggregate=score,
        tau_high=tau_high, tau_low=tau_low, per_detector={}, weights={},
        trust=1 - suspicion, suspicion=suspicion, context="TCP", unknown=unknown)


def test_high_score_low_suspicion_is_not_dropped():
    """A high score alone must not DROP without high suspicion + margin."""
    action, _, _ = S.choose_action(_decision(score=0.9, suspicion=0.2))
    assert action == "RATE_LIMIT"


def test_high_score_high_suspicion_quarantines():
    action, _, sev = S.choose_action(_decision(score=0.99, suspicion=0.95))
    assert action == "QUARANTINE"
    assert sev == "critical"


def test_unknown_family_is_redirected():
    action, reason, _ = S.choose_action(
        _decision(score=0.7, suspicion=0.5, unknown=True))
    assert action == "REDIRECT"
    assert "unknown" in reason.lower()


# --------------------------------------------------------------------------- #
# End-to-end: the whole engine holds the budget on the simulator              #
# --------------------------------------------------------------------------- #
def test_engine_end_to_end_holds_fp_budget():
    """The realized FPR should stay near (and under a small multiple of) the
    configured budget on the labeled simulator — the headline §11.4/H2 claim."""
    eng = S.SauronEngine(eps_h=0.02)
    src = S.SimSource(seed=42)
    for r in itertools.islice(src.stream(), 6000):
        eng.process(r)
    snap = eng.snapshot()
    assert snap["packets"] == 6000
    assert snap["realized_fpr"] <= 0.04, snap["realized_fpr"]     # < 2x budget
    assert snap["mcc"] > 0.4                                       # separates classes
    # containment stayed selective, not trigger-happy
    assert snap["quarantined"] <= snap["alerts"]

# ###########################################################################
# SECTION 2 — INTELLIGENCE LAYER  (backend/intelligence.py)
# ###########################################################################


def _feat(**kw):
    base = {f: 0.0 for f in I.FEATURES}
    base.update(kw)
    return base


# --------------------------------------------------------------------------- #
# ECOD: exact Shapley = additivity                                            #
# --------------------------------------------------------------------------- #
def test_ecod_contributions_are_exact_shapley():
    """For an additive score f(x)=sum_i g_i(x_i), the Shapley value of feature i
    is exactly g_i(x_i). We verify the returned contributions sum to the total
    tail-surprise (the additive score before the squashing link)."""
    ecod = I.ECOD(window=1000)
    rng = np.random.default_rng(0)
    for _ in range(600):                       # populate the streaming ECDF
        ecod.score(_feat(**{f: float(rng.uniform(0, 1)) for f in I.FEATURES}))

    probe = _feat(pps=0.99, dst_fanout=0.97, syn_ratio=0.9, iat=0.01)
    x = I.vectorize(probe)
    tails = ecod._tails(x)
    total = float(np.sum(tails))               # the additive surprise score

    # (a) the decomposition is EXACTLY additive — this is the exact-Shapley claim
    assert abs(float(np.sum(tails)) - total) < 1e-12

    # (b) the public contributions() are those same terms (rounded to 3 dp for
    #     display); they reconstruct the total within the rounding bound D*5e-4.
    contribs = dict(ecod.contributions(probe))
    assert abs(sum(contribs.values()) - total) < I.D * 5e-4 + 1e-9
    # every contribution is non-negative surprise
    assert all(v >= -1e-9 for v in contribs.values())


def test_ecod_flags_extremes_over_median():
    ecod = I.ECOD(window=800)
    rng = np.random.default_rng(1)
    for _ in range(800):
        ecod.score(_feat(**{f: 0.5 + 0.02 * rng.standard_normal() for f in I.FEATURES}))
    median_like = ecod.score(_feat(**{f: 0.5 for f in I.FEATURES}))
    extreme = ecod.score(_feat(**{f: 0.99 for f in I.FEATURES}))
    assert extreme > median_like


# --------------------------------------------------------------------------- #
# HDC classifier: learns separation, prototypes are bipolar (kernel-friendly) #
# --------------------------------------------------------------------------- #
def test_hdc_learns_class_separation():
    hdc = I.HDCClassifier(dim=1024, seed=11)
    rng = np.random.default_rng(2)
    for _ in range(400):
        benign = _feat(pkt_len=float(rng.uniform(0, 0.3)), iat=float(rng.uniform(0.5, 1)))
        malicious = _feat(pps=float(rng.uniform(0.7, 1)), dst_fanout=float(rng.uniform(0.7, 1)),
                          syn_ratio=1.0)
        hdc.learn(benign, 0)
        hdc.learn(malicious, 1)
    s_ben = hdc.score(_feat(pkt_len=0.1, iat=0.9))
    s_mal = hdc.score(_feat(pps=0.95, dst_fanout=0.9, syn_ratio=1.0))
    assert s_mal > s_ben
    assert 0.0 <= s_ben <= 1.0 and 0.0 <= s_mal <= 1.0


def test_hdc_quantized_prototypes_are_ternary():
    """The ±1 (bipolar) prototypes are the reason HDC is 'natively distillable to
    the kernel' — the quantized form must be in {-1,0,1}."""
    hdc = I.HDCClassifier(dim=256, seed=7)
    for _ in range(50):
        hdc.learn(_feat(pps=0.9), 1)
        hdc.learn(_feat(iat=0.9), 0)
    q = hdc.quantize_prototypes()
    for vec in q.values():
        assert set(np.unique(vec)).issubset({-1, 0, 1})


# --------------------------------------------------------------------------- #
# Drift martingale: fires on a real shift, quiet on stationary input          #
# --------------------------------------------------------------------------- #
def test_drift_martingale_quiet_when_stationary():
    dm = I.DriftMartingale(threshold=100.0)
    rng = np.random.default_rng(3)
    fired = sum(dm.update(float(rng.uniform(0, 1))) for _ in range(5000))
    # calibrated p-values ⇒ few (ideally zero) false alarms over a long run
    assert fired <= 2


def test_drift_martingale_fires_on_shift():
    dm = I.DriftMartingale(threshold=100.0)
    rng = np.random.default_rng(4)
    for _ in range(1000):
        dm.update(float(rng.uniform(0, 1)))           # in-distribution
    # a run of tiny p-values (anomalous) should trip the martingale
    fired = any(dm.update(0.001) for _ in range(200))
    assert fired
    assert dm.detections >= 1


# --------------------------------------------------------------------------- #
# Novel bank: bounded scores, attribution wired to ECOD                       #
# --------------------------------------------------------------------------- #
def test_novel_bank_scores_are_bounded():
    bank = I.NovelDetectorBank()
    rng = np.random.default_rng(5)
    for _ in range(300):
        f = _feat(**{k: float(rng.uniform(0, 1)) for k in I.FEATURES})
        sc = bank.scores(f, entity="10.0.0.1")
        assert set(sc.keys()) == set(bank.names)
        assert all(0.0 <= v <= 1.0 for v in sc.values())
    attr = bank.attribution(_feat(pps=0.9, dst_fanout=0.8))
    assert len(attr) == 3 and all(isinstance(k, str) for k, _ in attr)


# --------------------------------------------------------------------------- #
# Policy distiller: reported fidelity == independently-recomputed agreement    #
# --------------------------------------------------------------------------- #
def test_distiller_fidelity_is_measured_not_synthesized():
    """Recompute the fidelity of the top rule directly from the buffer and check
    it matches what distill() reported — proving the number is measured."""
    dist = I.PolicyDistiller(window=1500, min_fidelity=0.9, min_coverage=0.03)
    rng = np.random.default_rng(6)
    feats, labels = [], []
    for _ in range(1500):
        pps = float(rng.uniform(0, 1))
        enforced = 1 if pps > 0.8 else 0           # a clean underlying rule
        f = _feat(pps=pps, pkt_len=float(rng.uniform(0, 1)))
        dist.observe(f, enforced, "10.0.0.2")
        feats.append(I.vectorize(f)); labels.append(enforced)

    rules = dist.distill()
    assert rules, "expected at least one confident rule"
    top = rules[0]
    X = np.array(feats); y = np.array(labels)

    # rebuild the rule's boolean mask and recompute fidelity independently
    def col(name):
        return X[:, I.FEATURES.index(name)]

    def apply(op, a, thr):
        return a > thr if op == ">" else a < thr

    mask = apply(top["op"], col(top["feature"]), top["threshold"])
    if top.get("type") == "conj":
        mask = mask & apply(top["op2"], col(top["feature2"]), top["threshold2"])
    recomputed = float((y[mask] == 1).mean())
    assert abs(recomputed - top["fidelity"]) < 1e-6
    assert abs(float(mask.mean()) - top["coverage"]) < 1e-6


# --------------------------------------------------------------------------- #
# Alert manager: dedup + BH-FDR gate                                          #
# --------------------------------------------------------------------------- #
def _alert_ev(src, action, score, ts):
    return {"src_ip": src, "dst_ip": "10.0.0.9", "src_port": 5, "dst_port": 80,
            "action": action, "score": score, "ts": ts}


def test_alert_manager_dedups_within_window():
    am = I.AlertManager(dedup_sec=3.0)
    a = am.process(_alert_ev("1.1.1.1", "RATE_LIMIT", 0.9, ts=100.0))
    b = am.process(_alert_ev("1.1.1.1", "RATE_LIMIT", 0.9, ts=101.0))   # < 3s later
    c = am.process(_alert_ev("1.1.1.1", "RATE_LIMIT", 0.9, ts=105.0))   # > 3s later
    assert a is not None and b is None and c is not None
    assert am.suppressed >= 1


def test_alert_manager_quarantine_never_deduped():
    am = I.AlertManager(dedup_sec=10.0)
    a = am.process(_alert_ev("2.2.2.2", "QUARANTINE", 0.99, ts=100.0))
    b = am.process(_alert_ev("2.2.2.2", "QUARANTINE", 0.99, ts=100.5))
    assert a is not None and b is not None       # critical events always surface


def test_bh_threshold_matches_definition():
    """BH cutoff = largest p_(k) with p_(k) <= (k/m) q. Recompute and compare."""
    am = I.AlertManager(fdr_q=0.1)
    rng = np.random.default_rng(7)
    ps = list(rng.uniform(0, 1, size=300))
    for p in ps:
        # advisory (non-enforcement) events feed the p-buffer
        am.process(_alert_ev("3.3.3.3", "LOG", 1.0 - p, ts=rng.uniform(0, 1e6)))
    arr = np.sort(np.array(am.pbuf))
    n = len(arr)
    crit = am.fdr_q * (np.arange(1, n + 1) / n)
    below = np.where(arr <= crit)[0]
    expected = float(arr[below[-1]]) if len(below) else float(crit[0])
    assert abs(am.bh_threshold() - expected) < 1e-9


# --------------------------------------------------------------------------- #
# Autonomy governor: L2 rate cap + TTL expiry                                 #
# --------------------------------------------------------------------------- #
def test_autonomy_l2_rate_cap():
    gov = I.AutonomyGovernor(l2_per_min=60.0, ttl_sec=120.0)
    t = 1000.0
    allowed = sum(gov.allow_contain(f"10.0.0.{i}", now=t) for i in range(80))
    # burst of 80 at a single instant, bucket holds ~60 → the rest are capped
    assert allowed <= 61
    assert gov.capped >= 19


def test_autonomy_ttl_expiry_heals():
    gov = I.AutonomyGovernor(l2_per_min=600.0, ttl_sec=100.0)
    gov.allow_contain("9.9.9.9", now=0.0)
    assert gov.expired(now=50.0) == []           # still within TTL
    assert "9.9.9.9" in gov.expired(now=101.0)   # expired after TTL
    assert gov.expired(now=200.0) == []          # and removed


# --------------------------------------------------------------------------- #
# Storage: event + audit roundtrip                                            #
# --------------------------------------------------------------------------- #
def test_storage_event_and_audit_roundtrip():
    st = I.Storage(":memory:")
    for i in range(5):
        st.event({"ts": float(i), "src_ip": f"1.0.0.{i}", "dst_ip": "2.0.0.1",
                  "proto": "TCP", "action": "DROP", "score": 0.9,
                  "severity": "high", "reason": "test", "family": "synflood"})
    st.audit("eps_h_change", {"old": 0.02, "new": 0.05})
    ev = st.recent_events(10)
    assert len(ev) == 5 and ev[0]["action"] == "DROP"
    au = st.audit_tail(10)
    assert au and au[0]["kind"] == "eps_h_change" and au[0]["detail"]["new"] == 0.05

# ###########################################################################
# SECTION 3 — DISTRIBUTED MESH  (backend/grpc_service.py)
# ###########################################################################


# --------------------------------------------------------------------------- #
# Byzantine-robust federated aggregation                                      #
# --------------------------------------------------------------------------- #
def test_krum_rejects_a_byzantine_outlier():
    """Honest clients cluster near a point; one Byzantine client is far away.
    Krum must return a vector close to the honest cluster, not the outlier."""
    rng = np.random.default_rng(0)
    honest = [list(np.array([1.0, -2.0, 0.5]) + 0.05 * rng.standard_normal(3))
              for _ in range(6)]
    byz = [[100.0, -100.0, 100.0]]
    chosen = np.array(G._krum(honest + byz, f=1))
    assert np.linalg.norm(chosen - np.array([1.0, -2.0, 0.5])) < 0.5
    assert np.linalg.norm(chosen - np.array(byz[0])) > 10.0


def test_trimmed_mean_is_robust_to_outliers():
    """Coordinate-wise trimmed mean should ignore extreme poisoned coordinates
    and land near the honest mean."""
    honest = [[1.0, 1.0] for _ in range(8)]
    poisoned = honest + [[1e6, -1e6], [1e6, -1e6]]
    tm = G._trimmed_mean(poisoned, beta=0.2)
    assert tm == pytest.approx([1.0, 1.0], abs=1e-6)


def test_trimmed_mean_matches_plain_mean_without_outliers():
    vecs = [[0.0, 2.0], [1.0, 3.0], [2.0, 4.0], [3.0, 5.0], [4.0, 6.0]]
    tm = np.array(G._trimmed_mean(vecs, beta=0.2))
    # with beta=0.2 and n=5, one is trimmed each side → middle three averaged
    mid = np.mean(np.array(vecs)[1:4], axis=0)
    assert np.allclose(tm, mid)


# --------------------------------------------------------------------------- #
# phi-accrual failure detector                                                #
# --------------------------------------------------------------------------- #
def test_phi_accrual_rises_with_silence():
    """After regular heartbeats, phi should be low right after a beat and grow
    without bound as the peer goes silent past the mean interval."""
    pa = G.PhiAccrual()
    t = 0.0
    for _ in range(50):                      # steady 100 ms heartbeats
        pa.heartbeat(now_ms=t)
        t += 100.0
    phi_fresh = pa.phi(now_ms=t)             # just after a beat
    phi_late = pa.phi(now_ms=t + 1000.0)     # 10 intervals overdue
    assert phi_late > phi_fresh
    assert phi_late > 3.0                    # strong evidence of failure


def test_phi_accrual_zero_before_first_beat():
    pa = G.PhiAccrual()
    assert pa.phi(now_ms=123.0) == 0.0


# --------------------------------------------------------------------------- #
# Vector clocks: causal ordering                                              #
# --------------------------------------------------------------------------- #
def test_vector_clock_detects_causality():
    a = G.VClock("A")
    va1 = a.tick()                           # A:1
    b = G.VClock("B")
    b.merge(va1)                             # B learns A:1
    vb1 = b.tick()                           # {A:1, B:1}  (causally after va1)
    assert G.VClock.dominates(vb1, va1)
    assert not G.VClock.dominates(va1, vb1)


def test_vector_clock_flags_concurrency():
    a = G.VClock("A"); b = G.VClock("B")
    va = a.tick()                            # {A:1}
    vb = b.tick()                            # {B:1}  — concurrent with va
    assert not G.VClock.dominates(va, vb)
    assert not G.VClock.dominates(vb, va)


# --------------------------------------------------------------------------- #
# LWW-element-set CRDT (threat intel): convergence properties                 #
# --------------------------------------------------------------------------- #
def _node(node_id="N"):
    """Construct a MeshNode without starting any gRPC transport."""
    cfg = {"node_id": node_id, "advertise": "127.0.0.1:0", "region": "test",
           "seeds": [], "confidence_gate": 0.6}
    return G.MeshNode(engine=None, src_holder={}, cfg=cfg)


def _intel(ip, ts, action="DROP", conf=0.9):
    return {"src_ip": ip, "ts": ts, "action": action, "confidence": conf}


def test_crdt_lww_keeps_latest_timestamp():
    n = _node()
    n._merge_intel(_intel("5.5.5.5", ts=100.0, action="RATE_LIMIT"))
    n._merge_intel(_intel("5.5.5.5", ts=200.0, action="QUARANTINE"))
    n._merge_intel(_intel("5.5.5.5", ts=150.0, action="DROP"))   # stale, ignored
    assert n.intel["5.5.5.5"]["ts"] == 200.0
    assert n.intel["5.5.5.5"]["action"] == "QUARANTINE"


def test_crdt_merge_is_commutative():
    """Merging the same set of updates in any order yields identical state — the
    defining property of a CRDT (eventual consistency without coordination)."""
    updates = [_intel("1.1.1.1", 10.0), _intel("1.1.1.1", 30.0),
               _intel("2.2.2.2", 20.0), _intel("1.1.1.1", 25.0),
               _intel("2.2.2.2", 5.0)]
    n1 = _node("A")
    for u in updates:
        n1._merge_intel(u)
    n2 = _node("B")
    for u in reversed(updates):
        n2._merge_intel(u)

    def state(n):
        return {ip: rec["ts"] for ip, rec in n.intel.items()}

    assert state(n1) == state(n2)
    assert state(n1) == {"1.1.1.1": 30.0, "2.2.2.2": 20.0}


def test_crdt_merge_is_idempotent():
    n = _node()
    rec = _intel("7.7.7.7", ts=42.0)
    first = n._merge_intel(rec)
    again = n._merge_intel(rec)              # replaying the same record
    assert first is True                     # new actionable block
    assert again is False                    # no change on replay
    assert n.intel["7.7.7.7"]["ts"] == 42.0


def test_crdt_actionable_gate_respects_confidence():
    """Only high-confidence DROP/QUARANTINE records become actionable blocks;
    a low-confidence advisory must merge but not trigger a kernel block."""
    n = _node()
    assert n._merge_intel(_intel("8.8.8.8", ts=10.0, conf=0.2)) is False
    assert "8.8.8.8" in n.intel                 # still stored in the CRDT
    assert n._merge_intel(_intel("8.8.8.9", ts=10.0, conf=0.95)) is True
